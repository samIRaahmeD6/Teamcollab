import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import http from "http";
import { Server } from "socket.io";
import dotenv from "dotenv";
import userRoutes from "./routes/userRoutes.js";

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

// Attach io to req
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Routes
app.use("/api", userRoutes);

// Test route
app.get("/", (req, res) => res.send("✅ TeamCollab backend running..."));

// Socket.IO handling (same as before)
let onlineUsers = new Map();

io.on("connection", (socket) => {
  const userId = Number(socket.handshake.auth?.userId);
  if (!userId) return socket.disconnect(true);

  onlineUsers.set(userId, socket.id);
  io.emit("updateUsers", Array.from(onlineUsers.keys()));

  socket.on("logout", (id) => {
    onlineUsers.delete(Number(id));
    io.emit("updateUsers", Array.from(onlineUsers.keys()));
    socket.disconnect(true);
  });

  socket.on("disconnect", () => {
    onlineUsers.delete(userId);
    io.emit("updateUsers", Array.from(onlineUsers.keys()));
  });
});

server.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
